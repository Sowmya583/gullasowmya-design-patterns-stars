package Creational.factory_method_pattern;

public class Commericial extends Plan {
	@Override   
    public void getRate(){   
        rate=7.50;  
   }   

}
