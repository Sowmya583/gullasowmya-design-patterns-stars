package Creational.factory_method_pattern;

public class Domestic extends Plan {
	@Override
	 public void getRate(){  
         rate=3.50;              
    }  

}
